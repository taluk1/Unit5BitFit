package com.example.fitbit

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MoodAdapter(private var items: List<MoodEntity>) :
    RecyclerView.Adapter<MoodAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val mood: TextView = view.findViewById(R.id.moodTv)
        val note: TextView = view.findViewById(R.id.noteTv)
        val date: TextView = view.findViewById(R.id.dateTv)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_mood, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        holder.mood.text = e.mood
        holder.note.text = e.note
        holder.date.text = e.date
    }

    override fun getItemCount(): Int = items.size

    fun submit(newItems: List<MoodEntity>) {
        items = newItems
        notifyDataSetChanged()
    }
}