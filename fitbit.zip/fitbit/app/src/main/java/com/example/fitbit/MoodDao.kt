package com.example.fitbit

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MoodDao {
    @Query("SELECT * FROM mood_table ORDER BY id DESC")
    fun getAll(): Flow<List<MoodEntity>>

    @Insert
    suspend fun insert(entry: MoodEntity)
}