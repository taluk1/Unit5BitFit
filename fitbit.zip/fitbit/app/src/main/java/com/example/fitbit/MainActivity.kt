package com.example.fitbit

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val adapter = MoodAdapter(emptyList())
        val rv = findViewById<RecyclerView>(R.id.recyclerView)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        val dao = AppDatabase.getInstance(this).moodDao()
        lifecycleScope.launch {
            dao.getAll().collect { adapter.submit(it) }
        }

        findViewById<Button>(R.id.addBtn).setOnClickListener {
            startActivity(Intent(this, CreateEntryActivity::class.java))
        }
    }
}