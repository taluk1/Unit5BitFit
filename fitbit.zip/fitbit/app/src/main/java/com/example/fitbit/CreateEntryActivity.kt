package com.example.fitbit

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CreateEntryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_entry)

        val moodEt = findViewById<EditText>(R.id.moodEt)
        val noteEt = findViewById<EditText>(R.id.noteEt)

        findViewById<Button>(R.id.saveBtn).setOnClickListener {
            val date = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date())
            val entry = MoodEntity(
                mood = moodEt.text.toString(),
                note = noteEt.text.toString(),
                date = date
            )
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    AppDatabase.getInstance(this@CreateEntryActivity).moodDao().insert(entry)
                }
                finish()
            }
        }
    }
}